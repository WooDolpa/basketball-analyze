/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: basketball
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `cc_player`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_player` (
  `id` varchar(5) NOT NULL COMMENT '선수 아이디',
  `name` varchar(10) NOT NULL COMMENT '선수 이름',
  `eng_name` varchar(30) DEFAULT NULL COMMENT '선수 이름(영문)',
  `code` varchar(6) NOT NULL COMMENT '선수 코드',
  `profile_url` varchar(128) DEFAULT NULL COMMENT '프로필 이미지',
  `birth_date` varchar(8) DEFAULT NULL COMMENT '생년월일',
  `nationality` varchar(10) DEFAULT NULL COMMENT '국적',
  `division` char(1) DEFAULT NULL COMMENT '선수 구분(국내 : 0, 외국인 : 1, 아시아쿼터 : 2)',
  `height` decimal(5,2) NOT NULL COMMENT '키',
  `weight` decimal(5,2) DEFAULT NULL COMMENT '몸무게',
  `retirement` tinyint(1) NOT NULL DEFAULT 0 COMMENT '은퇴여부',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태 (Y : 사용, N : 미사용, D : 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='선수';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_player`
--

LOCK TABLES `cc_player` WRITE;
/*!40000 ALTER TABLE `cc_player` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season` (
  `id` varchar(9) NOT NULL COMMENT '시즌 아이디',
  `start_year` varchar(4) NOT NULL COMMENT '시작년도',
  `end_year` varchar(4) NOT NULL COMMENT '종료년도',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태 (Y : 사용, N : 미사용, D : 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시즌';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season`
--

LOCK TABLES `cc_season` WRITE;
/*!40000 ALTER TABLE `cc_season` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season_match`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season_match` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '시즌경기 아이디',
  `match_code` varchar(30) NOT NULL COMMENT 'KBL 경기 코드(재수집 중복 방지)',
  `cc_season_id` varchar(9) NOT NULL COMMENT '시즌 아이디',
  `match_datetime` datetime DEFAULT NULL COMMENT '예정 경기 시작 일시(KST), 일시 미정 NULL',
  `match_status` varchar(10) NOT NULL DEFAULT 'SCHEDULED' COMMENT '경기 상태(SCHEDULED: 예정, LIVE: 진행, FINISHED: 종료, POSTPONED: 연기, CANCELLED: 취소)',
  `home_season_team_id` varchar(12) NOT NULL COMMENT '홈팀 시즌 팀 아이디(경기와 동일 시즌)',
  `away_season_team_id` varchar(12) NOT NULL COMMENT '원정팀 시즌 팀 아이디(경기와 동일 시즌)',
  `win_type` varchar(4) DEFAULT NULL COMMENT '승리팀(HOME, AWAY), 경기 종료 전 NULL',
  `home_1q_score` tinyint(2) DEFAULT NULL COMMENT '홈팀 1쿼터 점수(미진행·미확인 NULL)',
  `home_2q_score` tinyint(2) DEFAULT NULL COMMENT '홈팀 2쿼터 점수(미진행·미확인 NULL)',
  `home_3q_score` tinyint(2) DEFAULT NULL COMMENT '홈팀 3쿼터 점수(미진행·미확인 NULL)',
  `home_4q_score` tinyint(2) DEFAULT NULL COMMENT '홈팀 4쿼터 점수(미진행·미확인 NULL)',
  `home_total_score` smallint(6) DEFAULT NULL COMMENT '홈팀 점수(진행 중 현재 점수, 종료 시 연장 포함 최종점수), 미확인 NULL',
  `away_1q_score` tinyint(2) DEFAULT NULL COMMENT '원정팀 1쿼터 점수(미진행·미확인 NULL)',
  `away_2q_score` tinyint(2) DEFAULT NULL COMMENT '원정팀 2쿼터 점수(미진행·미확인 NULL)',
  `away_3q_score` tinyint(2) DEFAULT NULL COMMENT '원정팀 3쿼터 점수(미진행·미확인 NULL)',
  `away_4q_score` tinyint(2) DEFAULT NULL COMMENT '원정팀 4쿼터 점수(미진행·미확인 NULL)',
  `away_total_score` smallint(6) DEFAULT NULL COMMENT '원정팀 점수(진행 중 현재 점수, 종료 시 연장 포함 최종점수), 미확인 NULL',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태 (Y : 사용, N : 미사용, D : 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_match_match_code` (`match_code`),
  KEY `fk_match_home_season_team` (`cc_season_id`,`home_season_team_id`),
  KEY `fk_match_away_season_team` (`cc_season_id`,`away_season_team_id`),
  CONSTRAINT `fk_match_away_season_team` FOREIGN KEY (`cc_season_id`, `away_season_team_id`) REFERENCES `cc_season_team` (`cc_season_id`, `id`),
  CONSTRAINT `fk_match_home_season_team` FOREIGN KEY (`cc_season_id`, `home_season_team_id`) REFERENCES `cc_season_team` (`cc_season_id`, `id`),
  CONSTRAINT `fk_match_season` FOREIGN KEY (`cc_season_id`) REFERENCES `cc_season` (`id`),
  CONSTRAINT `chk_cc_season_match_different_teams` CHECK (`home_season_team_id` <> `away_season_team_id`),
  CONSTRAINT `chk_cc_season_match_status` CHECK (`match_status` in ('SCHEDULED','LIVE','FINISHED','POSTPONED','CANCELLED')),
  CONSTRAINT `chk_cc_season_match_win_type` CHECK (`win_type` is null or `win_type` in ('HOME','AWAY')),
  CONSTRAINT `chk_cc_season_match_nonnegative_scores` CHECK ((`home_1q_score` is null or `home_1q_score` >= 0) and (`home_2q_score` is null or `home_2q_score` >= 0) and (`home_3q_score` is null or `home_3q_score` >= 0) and (`home_4q_score` is null or `home_4q_score` >= 0) and (`home_total_score` is null or `home_total_score` >= 0) and (`away_1q_score` is null or `away_1q_score` >= 0) and (`away_2q_score` is null or `away_2q_score` >= 0) and (`away_3q_score` is null or `away_3q_score` >= 0) and (`away_4q_score` is null or `away_4q_score` >= 0) and (`away_total_score` is null or `away_total_score` >= 0)),
  CONSTRAINT `chk_cc_season_match_result` CHECK (`match_status` = 'FINISHED' and `home_total_score` is not null and `away_total_score` is not null and `win_type` is not null and (`home_total_score` > `away_total_score` and `win_type` = 'HOME' or `away_total_score` > `home_total_score` and `win_type` = 'AWAY') or `match_status` <> 'FINISHED' and `win_type` is null)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시즌경기';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season_match`
--

LOCK TABLES `cc_season_match` WRITE;
/*!40000 ALTER TABLE `cc_season_match` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season_match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season_match_overtime`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season_match_overtime` (
  `cc_season_match_id` int(11) NOT NULL COMMENT '시즌경기 아이디',
  `overtime_no` smallint(6) NOT NULL COMMENT '연장 차수(1부터 시작)',
  `home_score` smallint(6) DEFAULT NULL COMMENT '해당 연장의 홈팀 점수(미확인 NULL)',
  `away_score` smallint(6) DEFAULT NULL COMMENT '해당 연장의 원정팀 점수(미확인 NULL)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`cc_season_match_id`,`overtime_no`),
  CONSTRAINT `fk_overtime_match` FOREIGN KEY (`cc_season_match_id`) REFERENCES `cc_season_match` (`id`),
  CONSTRAINT `chk_cc_season_match_overtime_no` CHECK (`overtime_no` >= 1),
  CONSTRAINT `chk_cc_season_match_overtime_nonnegative_scores` CHECK ((`home_score` is null or `home_score` >= 0) and (`away_score` is null or `away_score` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시즌 경기 연장 차수별 점수';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season_match_overtime`
--

LOCK TABLES `cc_season_match_overtime` WRITE;
/*!40000 ALTER TABLE `cc_season_match_overtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season_match_overtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season_match_player_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season_match_player_record` (
  `cc_season_match_id` int(11) NOT NULL COMMENT '시즌경기 아이디',
  `cc_player_id` varchar(5) NOT NULL COMMENT '선수 아이디',
  `cc_season_team_id` varchar(12) NOT NULL COMMENT '경기 당시 소속 시즌 팀 아이디',
  `is_starter` tinyint(1) DEFAULT NULL COMMENT '선발 출전 여부(미확인 NULL)',
  `playing_time_seconds` int(11) DEFAULT NULL COMMENT '해당 경기 전체 출전시간(초, 연장 포함)',
  `points` smallint(6) DEFAULT NULL COMMENT '해당 경기 득점',
  `offensive_rebounds` smallint(6) DEFAULT NULL COMMENT '해당 경기 공격 리바운드',
  `defensive_rebounds` smallint(6) DEFAULT NULL COMMENT '해당 경기 수비 리바운드',
  `rebounds` smallint(6) DEFAULT NULL COMMENT '해당 경기 전체 리바운드',
  `assists` smallint(6) DEFAULT NULL COMMENT '해당 경기 어시스트',
  `steals` smallint(6) DEFAULT NULL COMMENT '해당 경기 스틸',
  `blocks` smallint(6) DEFAULT NULL COMMENT '해당 경기 블록',
  `turnovers` smallint(6) DEFAULT NULL COMMENT '해당 경기 턴오버',
  `fouls` smallint(6) DEFAULT NULL COMMENT '해당 경기 파울',
  `field_goals_made` smallint(6) DEFAULT NULL COMMENT '해당 경기 전체 야투 성공 수',
  `field_goals_attempted` smallint(6) DEFAULT NULL COMMENT '해당 경기 전체 야투 시도 수',
  `two_pointers_made` smallint(6) DEFAULT NULL COMMENT '해당 경기 2점슛 성공 수',
  `two_pointers_attempted` smallint(6) DEFAULT NULL COMMENT '해당 경기 2점슛 시도 수',
  `three_pointers_made` smallint(6) DEFAULT NULL COMMENT '해당 경기 3점슛 성공 수',
  `three_pointers_attempted` smallint(6) DEFAULT NULL COMMENT '해당 경기 3점슛 시도 수',
  `free_throws_made` smallint(6) DEFAULT NULL COMMENT '해당 경기 자유투 성공 수',
  `free_throws_attempted` smallint(6) DEFAULT NULL COMMENT '해당 경기 자유투 시도 수',
  `plus_minus` smallint(6) DEFAULT NULL COMMENT '해당 선수 출전 중 팀 득실 마진(음수 허용)',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태(Y: 사용, N: 미사용, D: 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`cc_season_match_id`,`cc_player_id`),
  KEY `idx_match_player_record_player_match` (`cc_player_id`,`cc_season_match_id`),
  KEY `fk_match_player_record_roster` (`cc_season_team_id`,`cc_player_id`),
  CONSTRAINT `fk_match_player_record_match` FOREIGN KEY (`cc_season_match_id`) REFERENCES `cc_season_match` (`id`),
  CONSTRAINT `fk_match_player_record_roster` FOREIGN KEY (`cc_season_team_id`, `cc_player_id`) REFERENCES `cc_season_team_roster` (`cc_season_team_id`, `cc_player_id`),
  CONSTRAINT `chk_match_player_record_nonnegative` CHECK ((`playing_time_seconds` is null or `playing_time_seconds` >= 0) and (`points` is null or `points` >= 0) and (`offensive_rebounds` is null or `offensive_rebounds` >= 0) and (`defensive_rebounds` is null or `defensive_rebounds` >= 0) and (`rebounds` is null or `rebounds` >= 0) and (`assists` is null or `assists` >= 0) and (`steals` is null or `steals` >= 0) and (`blocks` is null or `blocks` >= 0) and (`turnovers` is null or `turnovers` >= 0) and (`fouls` is null or `fouls` >= 0) and (`field_goals_made` is null or `field_goals_made` >= 0) and (`field_goals_attempted` is null or `field_goals_attempted` >= 0) and (`two_pointers_made` is null or `two_pointers_made` >= 0) and (`two_pointers_attempted` is null or `two_pointers_attempted` >= 0) and (`three_pointers_made` is null or `three_pointers_made` >= 0) and (`three_pointers_attempted` is null or `three_pointers_attempted` >= 0) and (`free_throws_made` is null or `free_throws_made` >= 0) and (`free_throws_attempted` is null or `free_throws_attempted` >= 0)),
  CONSTRAINT `chk_match_player_record_shooting` CHECK ((`field_goals_made` is null or `field_goals_attempted` is null or `field_goals_made` <= `field_goals_attempted`) and (`two_pointers_made` is null or `two_pointers_attempted` is null or `two_pointers_made` <= `two_pointers_attempted`) and (`three_pointers_made` is null or `three_pointers_attempted` is null or `three_pointers_made` <= `three_pointers_attempted`) and (`free_throws_made` is null or `free_throws_attempted` is null or `free_throws_made` <= `free_throws_attempted`)),
  CONSTRAINT `chk_match_player_record_field_goals_made` CHECK (`field_goals_made` is null or `two_pointers_made` is null or `three_pointers_made` is null or `field_goals_made` = `two_pointers_made` + `three_pointers_made`),
  CONSTRAINT `chk_match_player_record_field_goals_attempted` CHECK (`field_goals_attempted` is null or `two_pointers_attempted` is null or `three_pointers_attempted` is null or `field_goals_attempted` = `two_pointers_attempted` + `three_pointers_attempted`),
  CONSTRAINT `chk_match_player_record_rebounds` CHECK (`rebounds` is null or `offensive_rebounds` is null or `defensive_rebounds` is null or `rebounds` = `offensive_rebounds` + `defensive_rebounds`),
  CONSTRAINT `chk_match_player_record_starter` CHECK (`is_starter` is null or `is_starter` in (0,1)),
  CONSTRAINT `chk_match_player_record_data_status` CHECK (`data_status` in ('Y','N','D'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='경기별 선수 개인기록(연장 포함)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season_match_player_record`
--

LOCK TABLES `cc_season_match_player_record` WRITE;
/*!40000 ALTER TABLE `cc_season_match_player_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season_match_player_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season_team`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season_team` (
  `id` varchar(12) NOT NULL COMMENT '시즌 팀 아이디(시즌 아이디 + 팀아이디)',
  `cc_season_id` varchar(9) NOT NULL COMMENT '시즌 아이디',
  `cc_team_id` varchar(3) NOT NULL COMMENT '팀아이디',
  `rank` tinyint(2) NOT NULL COMMENT '순위',
  `win` tinyint(2) NOT NULL COMMENT '승리',
  `lose` tinyint(2) NOT NULL COMMENT '패배',
  `win_percentage` decimal(3,2) NOT NULL COMMENT '승률',
  `games_behind` decimal(3,1) NOT NULL COMMENT '승차',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태 (Y : 사용, N : 미사용, D : 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cc_season_team_season_id` (`cc_season_id`,`id`),
  KEY `fk_season_team_team` (`cc_team_id`),
  CONSTRAINT `fk_season_team_season` FOREIGN KEY (`cc_season_id`) REFERENCES `cc_season` (`id`),
  CONSTRAINT `fk_season_team_team` FOREIGN KEY (`cc_team_id`) REFERENCES `cc_team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시즌 팀';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season_team`
--

LOCK TABLES `cc_season_team` WRITE;
/*!40000 ALTER TABLE `cc_season_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_season_team_roster`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_season_team_roster` (
  `cc_season_team_id` varchar(12) NOT NULL COMMENT '시즌 팀 아이디(시즌 아이디 + 팀아이디)',
  `cc_player_id` varchar(5) NOT NULL COMMENT '선수 아이디',
  `transfer` tinyint(1) NOT NULL DEFAULT 0 COMMENT '이적여부',
  `injury` tinyint(1) NOT NULL DEFAULT 0 COMMENT '부상여부',
  `game_count` smallint(6) DEFAULT NULL COMMENT '해당 시즌 소속팀 출전 경기 수',
  `playing_time_seconds` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 출전시간(초)',
  `points` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 득점',
  `offensive_rebounds` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 공격 리바운드',
  `defensive_rebounds` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 수비 리바운드',
  `rebounds` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 전체 리바운드',
  `assists` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 어시스트',
  `steals` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 스틸',
  `blocks` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 블록',
  `turnovers` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 턴오버',
  `fouls` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 파울',
  `field_goals_made` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 전체 야투 성공 수',
  `field_goals_attempted` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 전체 야투 시도 수',
  `two_pointers_made` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 2점슛 성공 수',
  `two_pointers_attempted` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 2점슛 시도 수',
  `three_pointers_made` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 3점슛 성공 수',
  `three_pointers_attempted` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 3점슛 시도 수',
  `free_throws_made` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 자유투 성공 수',
  `free_throws_attempted` int(11) DEFAULT NULL COMMENT '해당 시즌 소속팀 누적 자유투 시도 수',
  PRIMARY KEY (`cc_season_team_id`,`cc_player_id`),
  KEY `fk_roster_player` (`cc_player_id`),
  CONSTRAINT `fk_roster_player` FOREIGN KEY (`cc_player_id`) REFERENCES `cc_player` (`id`),
  CONSTRAINT `fk_roster_season_team` FOREIGN KEY (`cc_season_team_id`) REFERENCES `cc_season_team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시즌 팀 로스터';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_season_team_roster`
--

LOCK TABLES `cc_season_team_roster` WRITE;
/*!40000 ALTER TABLE `cc_season_team_roster` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_season_team_roster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_team`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_team` (
  `id` varchar(3) NOT NULL COMMENT '팀아이디',
  `name` varchar(10) NOT NULL COMMENT '팀명',
  `eng_name` varchar(20) DEFAULT NULL COMMENT '영문 이름',
  `data_status` char(1) NOT NULL COMMENT '데이터 상태 (Y : 사용, N : 미사용, D : 삭제)',
  `created_date` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `modified_date` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='팀';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_team`
--

LOCK TABLES `cc_team` WRITE;
/*!40000 ALTER TABLE `cc_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES
(1,'1','create basketball schema','SQL','V1__create_basketball_schema.sql',-1016374896,'basketball','2026-11-17 07:28:24',272,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-11-17  7:30:02
